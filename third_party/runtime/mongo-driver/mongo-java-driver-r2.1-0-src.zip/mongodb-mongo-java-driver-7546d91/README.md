## MongoDB Java Driver ##

driver home: http://github.com/mongodb/mongo-java-driver

mongodb home: http://www.mongodb.org/

#### Questions and Bug Reports
 * mailing list: http://groups.google.com/group/mongodb-user
 * jira: http://jira.mongodb.org/

## Change Log ##

##### v1.1 - 2009-12-10
* connections are pooled per Mongo

for full history, see: http://jira.mongodb.org/browse/JAVA


### Authors:
* Eliot Horowitz       eliot@10gen.com
* Kristina Chodorow    kristina@10gen.com
* Geir Magnusson       geir@pobox.com
* Keith Branton        mongoDBjira@branton.co.uk
* Dave Brosius         dbrosius@mebigfatguy.com


 
